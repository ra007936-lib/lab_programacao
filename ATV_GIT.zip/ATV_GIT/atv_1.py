V=[]
D=[]

for i in range(10):
    n=int(input(f'Digite o {i+1}º valor: '))
    V.append(n)

contador=0

for x in V:
    if x not in D:
        D.append(x)
        contador+=1

print(V)
print(f'Foram encontrados {contador} valores diferentes')