D=[]
c=0

for i in range(50):
    n=int(input(f'Digite o {i+1}º lançamento do dado: '))
    D.append(n)

for w in D:
    if (w == 6):
        c+=1

p=(c*100)/50

print(D)
print(f'A face 6 apareceu {c} vezes')
print(f'O percentual foi de {p}%')