V=[]

for i in range(5):
    n=int(input(f'Digite o valor: '))
    V.append(n)

x=int(input('Digite o valor x: '))

posicao=-1

for i in range(5):
    if V (i == x):
        posicao=i
        break

print(V)
print(f'O valor x aparece primeiro na posição {posicao}')